
	custom = function()
	{

		
	};

	custom.timeLeftStr = function(seconds,hourSet)//aktualizuje po prostu, nie ma sensu zapisywac tych danych do pliku
	{
			hour   = Math.floor(seconds / 3600);
			min = Math.floor((seconds - (hour * 3600)) / 60);
			sec = seconds - (hour * 3600) - (min * 60);
			if (hour   < 10) {hour   = "0"+hour;}
			if (min < 10) {min = "0"+min;}
			if (sec < 10) {sec = "0"+sec;}
		if(hourSet)
		{
			return hour+':'+min+':'+sec;
		}
		else
		{
			return min+':'+sec;
		}
	};