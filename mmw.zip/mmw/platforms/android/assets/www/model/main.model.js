var mainModel = function()
{
	this.$http = angular.injector(["ng"]).get("$http");
	
};

	
	
	mainModel.wpierdolUpdate = function(seconds,scope)
	{
		clearInterval(wpierdolTimer);
		var sec = seconds;
		if(sec > 0)
		{
			scope.$apply(function() {
				scope.menuWpierdolTimer = custom.timeLeftStr(sec, 0);
				scope.menuWpierdolTimerShow = true;
			});
		}
		wpierdolTimer = setInterval((function(){
			sec--;
			if(sec <= 0)
			{
				clearInterval(wpierdolTimer);
				mainModel.updatePlayer();
			}
			scope.$apply(function() {
				scope.menuWpierdolTimer = custom.timeLeftStr(sec, 0);
				scope.menuWpierdolTimerShow = true;
			});
			
		}).bind(scope),1000);
	};
	
	
	mainModel.chcicaUpdate = function(seconds,scope)
	{
		clearInterval(chcicaTimer);
		var sec = seconds;
		if(sec > 0)
		{
			scope.$apply(function() {
				scope.menuChcicaTimer = custom.timeLeftStr(sec, 0);
				scope.menuChcicaTimerShow = true;
			});
		}
		chcicaTimer = setInterval((function(){
			sec--;
			if(sec <= 0)
			{
				clearInterval(chcicaTimer);
				mainModel.updatePlayer();
			}
			scope.$apply(function() {
				scope.menuChcicaTimer = custom.timeLeftStr(sec, 0);
				scope.menuChcicaTimerShow = true;
			});
		}).bind(scope),1000);
	};
	
	mainModel.zmeczenieUpdate = function(seconds,scope)
	{
		clearInterval(zmeczenieTimer);
		var sec = seconds;
		if(sec > 0)
		{
			scope.$apply(function() {
				scope.menuZmeczenieTimer = custom.timeLeftStr(sec, 0);
				scope.menuZmeczenieTimerShow = true;
			});
		}		
		zmeczenieTimer = setInterval((function(){
			sec--;
			if(sec <= 0)
			{
				clearInterval(zmeczenieTimer);
				mainModel.updatePlayer();
			}
			scope.$apply(function() {
				scope.menuZmeczenieTimer = custom.timeLeftStr(sec, 0);
				scope.menuZmeczenieTimerShow = true;
			});
		}).bind(scope),1000);
	}
	
	
	

	mainModel.updatePlayer = function()//aktualizuje po prostu, nie ma sensu zapisywac tych danych do pliku
	{
		$http = angular.injector(["ng"]).get("$http");
		
		$http.post(connectionDomain+'/?typ=main&section=player&action=getData&device='+deviceID).then(function(response){
			var scope = angular.element(document.getElementById("menuData")).scope();
					scope.$apply(function() {
						scope.menuLevel = response.data.level;
						scope.menuPremium = response.data.premium;
						scope.menuHajs = response.data.hajs;
						
						scope.menuWpierdolMax = response.data.wpierdolMax;
						scope.menuWpierdol = response.data.wpierdol;
						
						scope.menuChcicaMax = response.data.chcicaMax;
						scope.menuChcica = response.data.chcica;
						
						scope.menuZmeczenieMax = response.data.zmeczenieMax;
						scope.menuZmeczenie = response.data.zmeczenie;
				});
			if(response.data.wpierdolSeconds > 0)
			{
				mainModel.wpierdolUpdate(response.data.wpierdolSeconds,scope);
			}
			else
			{
				scope.$apply(function() {
					scope.menuWpierdolTimerShow = false;
				});
			}
			
			
			if(response.data.chcicaSeconds > 0)
			{
				mainModel.chcicaUpdate(response.data.chcicaSeconds,scope);
			}
			else
			{
				scope.$apply(function() {
					scope.menuChcicaTimerShow = false;
				});
			}
			
			
			
			if(response.data.zmeczenieSeconds > 0)
			{
				mainModel.zmeczenieUpdate(response.data.zmeczenieSeconds,scope);
			}
			else
			{
				scope.$apply(function() {
					scope.menuZmeczenieTimerShow = false;
				});
			}
			
			
			
		}, function(err){
			console.log(err);
		});
		//pobierze dane i zapisze do pliku!
	}
	
	
	
	mainModel.downloadSettings = function()
	{
		$http = angular.injector(["ng"]).get("$http");
		$http.post(connectionDomain+'/?typ=main&section=player&action=getSettings&device='+deviceID).then(function(response){
			console.log(response);
		}, function(err){
			console.log(err);
		});	
	}


mainModel.prototype = {
	
	
	

	
	
	
}

