var latarniaModel = function()
{
	
	
};
//zawsze to mozna zamenic na dane z ajaxa!
latarniaModel.prototype = {
	
	
	
	getLocations: function()
	{

		$http = angular.injector(["ng"]).get("$http");
		console.log(user);
		$http.post(connectionDomain+'/?typ=main&section=latarnia&action=needDownloadLoc&user='+user).then(function(response){
			console.log(response);
			if(response.data.needDownload == 0)
			{
				$http.post(connectionDomain+'/?typ=main&section=latarnia&action=downloadCurrentLocation&user='+user).then(function(response){
					console.log(response.data);
					
				});
				
				
			}
			else
			{
				console.log("sa zapisane!");
				
			}
		}, function(err){
			console.log(err);
		});
		
	},
	/*
	getLocations: function()
	{
		
		
		
		
		
	}
	*/
	
	/*
	getLocations: function()
	{
		
		var locationIcon = [];
		locationIcon[locationIcon.length] = { "nazwa": "Dyskoteka", "icon": "assets/images/latarnia/dyskoteka.png", "level":0, "locID":1, "lock":0 };
		locationIcon[locationIcon.length] = { "nazwa": "Autostrada", "icon": "assets/images/latarnia/autostrada.png", "level":5, "locID":2, "lock":1 };
		
		locationIcon[locationIcon.length] = { "nazwa": "Ciemna Uliczka", "icon": "assets/images/latarnia/ciemna_uliczka.png", "level":7, "locID":3, "lock":1};
		locationIcon[locationIcon.length] = { "nazwa": "Motel", "icon": "assets/images/latarnia/motel.png", "level":10, "locID":4, "lock":1 };	
		locationIcon[locationIcon.length] = { "nazwa": "Kibel", "icon": "assets/images/latarnia/kibel.png", "level":12, "locID":5, "lock":1 };
		locationIcon[locationIcon.length] = { "nazwa": "U klienta", "icon": "assets/images/latarnia/u_klienta.png", "level":15, "locID":6, "lock":1 };
		locationIcon[locationIcon.length] = { "nazwa": "Hotel", "icon": "assets/images/latarnia/hotel.png", "level":18, "locID":7, "lock":1 };
		locationIcon[locationIcon.length] = { "nazwa": "Auto", "icon": "assets/images/latarnia/auto.png", "level":20, "locID":8, "lock":1 };	
		locationIcon[locationIcon.length] = { "nazwa": "Park", "icon": "assets/images/latarnia/park.png", "level":23, "locID":9, "lock":1 };
		locationIcon[locationIcon.length] = { "nazwa": "Kino", "icon": "assets/images/latarnia/kino.png", "level":28, "locID":10, "lock":1 };
		locationIcon[locationIcon.length] = { "nazwa": "Samolot", "icon": "assets/images/latarnia/samolot.png", "level":35, "locID":11, "lock":1 };
		locationIcon[locationIcon.length] = { "nazwa": "Łódź", "icon": "assets/images/latarnia/lodz.png", "level":40, "locID":12, "lock":1 };	
		locationIcon[locationIcon.length] = { "nazwa": "Las", "icon": "assets/images/latarnia/las.png", "level":44, "locID":13, "lock":1 };
		locationIcon[locationIcon.length] = { "nazwa": "Plaża", "icon": "assets/images/latarnia/plaza.png", "level":47, "locID":14, "lock":1 };
		locationIcon[locationIcon.length] = { "nazwa": "Cmentarz", "icon": "assets/images/latarnia/cmentarz.png", "level":52, "locID":15, "lock":1 };
		locationIcon[locationIcon.length] = { "nazwa": "Plebania", "icon": "assets/images/latarnia/plebania.png", "level":57, "locID":16, "lock":1 };	
		locationIcon[locationIcon.length] = { "nazwa": "Biuro", "icon": "assets/images/latarnia/biuro.png", "level":60, "locID":17, "lock":1 };
		locationIcon[locationIcon.length] = { "nazwa": "Sejm", "icon": "assets/images/latarnia/sejm.png", "level":65, "locID":18, "lock":1 };
		locationIcon[locationIcon.length] = { "nazwa": "Szkoła", "icon": "assets/images/latarnia/szkola.png", "level":70, "locID":19, "lock":1 };
		locationIcon[locationIcon.length] = { "nazwa": "Willa", "icon": "assets/images/latarnia/willa.png", "level":80, "locID":20, "lock":1 };	
		locationIcon[locationIcon.length] = { "nazwa": "Dżungla", "icon": "assets/images/latarnia/dzungla.png", "level":90, "locID":21, "lock":1 };
		locationIcon[locationIcon.length] = { "nazwa": "Lochy", "icon": "assets/images/latarnia/lochy.png", "level":100, "locID":22, "lock":1 };
		locationIcon[locationIcon.length] = { "nazwa": "Winda", "icon": "assets/images/latarnia/winda.png", "level":110, "locID":23, "lock":1 };
		locationIcon[locationIcon.length] = { "nazwa": "Butik", "icon": "assets/images/latarnia/butik.png", "level":120, "locID":24, "lock":1 };	
		locationIcon[locationIcon.length] = { "nazwa": "Rejst Statkiem", "icon": "assets/images/latarnia/rejsStatkiem.png", "level":130, "locID":25, "lock":1 };

		
		
		return locationIcon;
		
	}
	*/
	
	
}